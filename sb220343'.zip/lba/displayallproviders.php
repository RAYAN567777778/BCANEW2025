<!DOCTYPE html>
<html>
<body>
<?php
// Connect to MySQL using mysqli
$con = new mysqli("localhost", "root", "", "lbaservice");

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

// Fetch data from provider table
$result = $con->query("SELECT * FROM provider");

if ($result->num_rows > 0) {
    echo '<table border="1">
    <tr> 
        <th>ID</th>
        <th>Name</th>
        <th>Address</th>
        <th>Latitude</th>
        <th>Longitude</th>
        <th>City</th>
        <th>Area</th>
        <th>Email</th>
        <th>Website</th>
        <th>Logo</th>
    </tr>';

    while($row = $result->fetch_assoc()) {
        echo '<tr>
            <td>' . $row['p_id'] . '</td> 
            <td>' . $row['p_name'] . '</td>
            <td>' . $row['p_address'] . '</td>
            <td>' . $row['p_lat'] . '</td>
            <td>' . $row['p_long'] . '</td>
            <td>' . $row['p_city'] . '</td>
            <td>' . $row['p_area'] . '</td>
            <td>' . $row['p_email'] . '</td>
            <td>' . $row['p_website'] . '</td>
            <td><img src="' . $row['p_logo'] . '" width="300" height="200"></td>
        </tr>';
    }

    echo '</table><br><a href="adminui.html">Back To Admin UI</a><br>';
} else {
    echo "<h3>No records found in 'provider' table.</h3>";
}

$con->close();
?>
</body>
</html>
