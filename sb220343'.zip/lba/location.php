<!DOCTYPE html>
<html>
<head>
    <title>Search Offers by Category</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        #searchForm {
            background: #f5f5f5;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        #searchForm label {
            font-weight: bold;
            margin-right: 10px;
        }
        #searchForm input[type="text"] {
            padding: 8px;
            width: 300px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        #searchForm input[type="submit"] {
            padding: 8px 15px;
            background: #4285f4;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        #searchForm input[type="submit"]:hover {
            background: #3367d6;
        }
        #resultsTable {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        #resultsTable th, #resultsTable td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        #resultsTable th {
            background-color: #f2f2f2;
        }
        #googleMap {
            width: 100%;
            height: 500px;
            border: 1px solid #ddd;
            margin-top: 20px;
        }
        #mapError {
            color: #d32f2f;
            margin: 10px 0;
            padding: 10px;
            background: #ffebee;
            border-radius: 4px;
        }
        .no-results {
            color: #666;
            font-style: italic;
        }
    </style>
</head>
<body>

<div id="searchForm">
    <h2>Search Offers by Category</h2>
    <form method="POST">
        <label for="category">Category:</label>
        <input type="text" id="category" name="category" required placeholder="Enter category...">
        <input type="submit" name="submit" value="Search">
    </form>
</div>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $category = htmlspecialchars($_POST['category']);

    // Database configuration
    $db_host = "localhost";
    $db_user = "root";
    $db_pass = "";
    $db_name = "lbaservice";

    // Connect to MySQL using mysqli
    $con = new mysqli($db_host, $db_user, $db_pass, $db_name);
    
    if ($con->connect_error) {
        die("<div class='no-results'>Connection failed: " . $con->connect_error . "</div>");
    }

    // Query for coordinates by category
    $stmt = $con->prepare("SELECT o_title, o_lat, o_long FROM offer WHERE o_category = ?");
    $stmt->bind_param("s", $category);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<h3>Results for category: <em>" . htmlspecialchars($category) . "</em></h3>";
        echo "<table id='resultsTable'>
                <tr>
                    <th>Title</th>
                    <th>Latitude</th>
                    <th>Longitude</th>
                </tr>";

        // Prepare Google Map coordinates array
        $coordinates = [];
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . htmlspecialchars($row['o_title']) . "</td>
                    <td>" . htmlspecialchars($row['o_lat']) . "</td>
                    <td>" . htmlspecialchars($row['o_long']) . "</td>
                  </tr>";
            
            // Collect coordinates for map (convert to float)
            $coordinates[] = [
                'title' => $row['o_title'],
                'lat' => floatval($row['o_lat']),
                'lng' => floatval($row['o_long'])
            ];
        }
        echo "</table>";

        // Display the map container
        echo "<h3>Location Map</h3>";
        echo "<div id='googleMap'></div>";
        echo "<div id='mapError'></div>";

        // Convert coordinates array to JSON
        $coordinates_json = json_encode($coordinates);

        // JavaScript for Google Maps
        echo "<script>
                // Function to initialize the map
                function initMap() {
                    try {
                        var markers = $coordinates_json;
                        
                        if (!markers || markers.length === 0) {
                            throw new Error('No locations to display on map');
                        }
                        
                        // Calculate the map center
                        var center = calculateCenter(markers);
                        
                        // Create the map
                        var map = new google.maps.Map(document.getElementById('googleMap'), {
                            zoom: 12,
                            center: center,
                            mapTypeId: 'roadmap'
                        });
                        
                        // Create markers and info windows
                        markers.forEach(function(marker) {
                            var position = new google.maps.LatLng(marker.lat, marker.lng);
                            var mapMarker = new google.maps.Marker({
                                position: position,
                                map: map,
                                title: marker.title
                            });
                            

                            // Add info window
                            var infowindow = new google.maps.InfoWindow({
                                content: '<h3>' + marker.title + '</h3>' +
                                         '<p>Lat: ' + marker.lat + '</p>' +
                                         '<p>Lng: ' + marker.lng + '</p>'
                            });
                            

                            mapMarker.addListener('click', function() {
                                infowindow.open(map, mapMarker);
                            });
                        });
                        
                    } catch (error) {
                        document.getElementById('mapError').innerHTML = 'Map Error: ' + error.message;
                        console.error(error);
                    }
                }
                
                // Helper function to calculate map center
                function calculateCenter(markers) {
                    if (markers.length === 1) {
                        return { lat: markers[0].lat, lng: markers[0].lng };
                    }
                    
                    var latSum = 0, lngSum = 0;
                    markers.forEach(function(marker) {
                        latSum += marker.lat;
                        lngSum += marker.lng;
                    });
                    
                    return { 
                        lat: latSum / markers.length, 
                        lng: lngSum / markers.length 
                    };
                }
                
                // Function to load Google Maps API
                function loadGoogleMapsAPI() {
                    // Replace with your actual API key
                    var apiKey = 'AIzaSyA4RKDWn0lwizH9Tm2BFWUGa-pMn_xZ8bM';
                    
                    if (!apiKey || apiKey === 'YOUR_GOOGLE_MAPS_API_KEY') {
                        document.getElementById('mapError').innerHTML = 
                            'Google Maps API key is missing or invalid. Please configure a valid API key.';
                        return;
                    }
                    
                    var script = document.createElement('script');
                    script.src = 'https://maps.googleapis.com/maps/api/js?key=' + apiKey + '&callback=initMap';
                    script.async = true;
                    script.defer = true;
                    script.onerror = function() {
                        document.getElementById('mapError').innerHTML = 
                            'Failed to load Google Maps API. Please check your internet connection and API key.';
                    };
                    document.head.appendChild(script);
                }
                
                // Load Google Maps API when page is ready
                if (window.addEventListener) {
                    window.addEventListener('load', loadGoogleMapsAPI);
                } else if (window.attachEvent) {
                    window.attachEvent('onload', loadGoogleMapsAPI);
                } else {
                    window.onload = loadGoogleMapsAPI;
                }
            </script>";
    } else {
        echo "<p class='no-results'>No results found for category: <strong>" . htmlspecialchars($category) . "</strong></p>";
    }

    $stmt->close();
    $con->close();
}
?>

</body>
</html>
