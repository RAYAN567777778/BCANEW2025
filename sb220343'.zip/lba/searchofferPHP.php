<?php
// Create connection to XAMPP local MySQL
$con = new mysqli("localhost", "root", "", "lbaservice");

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

// Get POST values safely
$o_id = $_POST['o_id'] ?? '';
$o_title = $_POST['o_title'] ?? '';
$o_city = $_POST['o_city'] ?? '';

// Prepare and run query (use LIKE if partial match is needed)
$sql = "SELECT * FROM offer WHERE o_id = ? OR o_title = ? OR o_city = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("sss", $o_id, $o_title, $o_city);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "No Match Found";
} else {
    echo '<table border=1>
    <tr> 
    <th>Offer ID</th>
    <th>Provider ID</th>
    <th>Title</th>
    <th>Description</th>
    <th>Price</th>
    <th>Discount</th>
    <th>City</th>
    <th>Area</th>
    <th>Address</th>
    <th>Latitude</th>
    <th>Longitude</th>
    <th>Contact</th>
    <th>Category</th>
    <th>Expiry Date</th>
    <th>Valid</th>
    <th>Link</th>
    <th>Photo</th>
    </tr>';

    while ($row = $result->fetch_assoc()) {
        echo '<tr>
        <td>' . $row['o_id'] . '</td>
        <td>' . $row['op_id'] . '</td>
        <td>' . $row['o_title'] . '</td>
        <td>' . $row['o_description'] . '</td>
        <td>' . $row['o_price'] . '</td>
        <td>' . $row['o_discount'] . '</td>
        <td>' . $row['o_city'] . '</td>
        <td>' . $row['o_area'] . '</td>
        <td>' . $row['o_address'] . '</td>
        <td>' . $row['o_lat'] . '</td>
        <td>' . $row['o_long'] . '</td>
        <td>' . $row['o_contact'] . '</td>
        <td>' . $row['o_category'] . '</td>
        <td>' . $row['o_expiry'] . '</td>
        <td>' . $row['o_valid'] . '</td>
        <td>' . $row['o_link'] . '</td>
        <td><img src="' . $row['o_photo'] . '" width="300" height="200"></td>
        </tr>';
    }

    echo '</table>';
}

$stmt->close();
$con->close();
?>
