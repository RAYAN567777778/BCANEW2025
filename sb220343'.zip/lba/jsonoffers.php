<?php
header('Content-Type: application/json');

// Connect to MySQL using mysqli
$con = new mysqli("localhost", "root", "", "lbaservice");

// Check connection
if ($con->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $con->connect_error]));
}

// Query the 'offer' table
$sql = "SELECT * FROM offer";
$result = $con->query($sql);

// Prepare output
$output = [];

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $output[] = $row;
    }
}

// Print JSON output
echo json_encode($output);

// Close connection
$con->close();
?>
