<html>
<body>

<form action="login.php" method="post">
Username: <input type="text" name="u_name"><br>
Password: <input type="password" name="pwd"><br>
<input type="submit">
</form>

</body>
</html>