<?php
// Show errors for debugging (disable in production)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// DB connection (localhost, root user, no password, database: lbaservice)
$con = new mysqli("localhost", "root", "", "lbaservice");
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

// Get next available o_id
$result = $con->query("SELECT MAX(o_id) AS max_id FROM offer");
$row = $result->fetch_assoc();
$highest_id = $row['max_id'] + 1;

// Collect POST values
$op_id       = $_POST['op_id'];
$otitle      = $_POST['o_title'];
$odescription= $_POST['o_description'];
$oprice      = $_POST['o_price'];
$odiscount   = $_POST['o_discount'];
$ocity       = $_POST['o_city'];
$oarea       = $_POST['o_area'];
$oaddress    = $_POST['o_address'];
$olat        = $_POST['o_lat'];
$olong       = $_POST['o_long'];
$ocontact    = $_POST['o_contact'];
$ocategory   = $_POST['o_category'];
$oexpiry     = $_POST['o_expiry'];
$ovalid      = $_POST['o_valid'];
$olink       = $_POST['o_link'];

// Handle file upload
$upload_dir = "images/";
$original_filename = $_FILES['file_upload']['name'];
$extension = pathinfo($original_filename, PATHINFO_EXTENSION);
$newfilename = $highest_id . "." . $extension;
$target_path = $upload_dir . $newfilename;

if (!move_uploaded_file($_FILES['file_upload']['tmp_name'], $target_path)) {
    die('Error uploading file. Check that "images/" folder is writable.');
}

$photo_url = $target_path; // for local XAMPP use relative path

// Insert into database
$stmt = $con->prepare("INSERT INTO offer (op_id, o_title, o_description, o_price, o_discount, o_photo, o_city, o_area, o_address, o_lat, o_long, o_contact, o_category, o_expiry, o_valid, o_link)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

$stmt->bind_param("issddssssddssssss", $op_id, $otitle, $odescription, $oprice, $odiscount, $photo_url, $ocity, $oarea, $oaddress, $olat, $olong, $ocontact, $ocategory, $oexpiry, $ovalid, $olink);

if ($stmt->execute()) {
    echo "1 record added successfully.<br><a href='adminui.html'>Back To Admin UI</a><br>";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$con->close();
?>
