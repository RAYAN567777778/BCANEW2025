<!DOCTYPE html>
<html>
<body>
<?php
// Enable error reporting (for debugging; disable in production)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Connect to local MySQL
$con = new mysqli("localhost", "root", "", "lbaservice");
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

// Prepare and bind (safely allow any field to be optional)
$p_id = $_POST['p_id'] ?? '';
$p_name = $_POST['p_name'] ?? '';
$p_city = $_POST['p_city'] ?? '';

// Build dynamic query (only include conditions if fields are provided)
$conditions = [];
$params = [];
$types = '';

if (!empty($p_id)) {
    $conditions[] = "p_id = ?";
    $params[] = $p_id;
    $types .= 'i';
}
if (!empty($p_name)) {
    $conditions[] = "p_name = ?";
    $params[] = $p_name;
    $types .= 's';
}
if (!empty($p_city)) {
    $conditions[] = "p_city = ?";
    $params[] = $p_city;
    $types .= 's';
}

if (empty($conditions)) {
    echo "Please enter at least one search field.";
    exit;
}

$sql = "SELECT * FROM provider WHERE " . implode(" OR ", $conditions);
$stmt = $con->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "No Match Found";
} else {
    echo '<table border=1>
    <tr> 
    <th>ID</th>
    <th>Name</th>
    <th>Address</th>
    <th>Latitude</th>
    <th>Longitude</th>
    <th>City</th>
    <th>Area</th>
    <th>Email</th>
    <th>Website</th>
    <th>Logo</th>
    </tr>';

    while($row = $result->fetch_assoc()) {
        echo '<tr>
        <td>' .$row['p_id']. '</td> 
        <td>' .$row['p_name']. '</td>
        <td>' .$row['p_address']. '</td>
        <td>' .$row['p_lat']. '</td>
        <td>' .$row['p_long']. '</td>
        <td>' .$row['p_city']. '</td>
        <td>' .$row['p_area']. '</td>
        <td>' .$row['p_email']. '</td>
        <td>' .$row['p_website']. '</td>
        <td><img src="' .$row['p_logo']. '" width=300 height=200></td> 
        </tr>';
    }

    echo '</table><br><a href="adminui.html">Back To Admin UI</a><br>';
}

$stmt->close();
$con->close();
?>
</body>
</html>
