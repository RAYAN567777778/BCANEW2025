<?php
// Enable error reporting (disable in production)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Connect to local database
$con = new mysqli("localhost", "root", "", "lbaservice");
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

// Get next p_id
$result = $con->query("SELECT MAX(p_id) AS max_id FROM provider");
$row = $result->fetch_assoc();
$highest_id = $row['max_id'] + 1;

// Get POST data
$pname     = $_POST['p_name'];
$paddress  = $_POST['p_address'];
$plat      = $_POST['p_lat'];
$plong     = $_POST['p_long'];
$pcity     = $_POST['p_city'];
$parea     = $_POST['p_area'];
$pcontact  = $_POST['p_contact'];
$pemail    = $_POST['p_email'];
$pwebsite  = $_POST['p_website'];

// Display info (debug)
echo "Name: $pname<br>Address: $paddress<br>Lat: $plat<br>Long: $plong<br>City: $pcity<br>Area: $parea<br>Contact: $pcontact<br>Email: $pemail<br>Website: $pwebsite<br>";

// Upload logo
$upload_dir = "logo/";
$filename = $_FILES['file_upload']['name'];
$extension = pathinfo($filename, PATHINFO_EXTENSION);
$newfilename = $highest_id . "." . $extension;
$target_path = $upload_dir . $newfilename;

if (!move_uploaded_file($_FILES['file_upload']['tmp_name'], $target_path)) {
    die("File upload failed. Make sure 'logo/' folder is writable.");
}

echo "File uploaded successfully.<br>";

// Prepare insert query
$stmt = $con->prepare("INSERT INTO provider (p_name, p_address, p_lat, p_long, p_city, p_area, p_contact, p_email, p_website, p_logo) 
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

$logo_url = $target_path; // Relative path for localhost use

$stmt->bind_param("ssddssssss", $pname, $paddress, $plat, $plong, $pcity, $parea, $pcontact, $pemail, $pwebsite, $logo_url);

if ($stmt->execute()) {
    echo "1 record added successfully.<br><a href='adminui.html'>Back To Admin UI</a>";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$con->close();
?>
