<?php
// Start session if needed
session_start();

// Get POST data safely
$username = $_POST['u_name'];
$password = $_POST['pwd'];

// Connect to MySQL using mysqli
$conn = new mysqli("localhost", "root", "", "lbaservice");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Use prepared statements to avoid SQL injection
$stmt = $conn->prepare("SELECT * FROM users WHERE u_name = ? AND pwd = ?");
$stmt->bind_param("ss", $username, $password);
$stmt->execute();
$result = $stmt->get_result();




// Check if user exists
if ($result->num_rows === 1) {
    // Optional: set session variables
    $_SESSION['username'] = $username;
    header("Location: adminui.html");
    exit();
} else {
    echo "<h3>You are NOT a Registered User!!</h3>";
}

$stmt->close();
$conn->close();
?>